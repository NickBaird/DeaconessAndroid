package com.example.weightloss_pathway_project

class Quote {
    val quote : String = String()
}