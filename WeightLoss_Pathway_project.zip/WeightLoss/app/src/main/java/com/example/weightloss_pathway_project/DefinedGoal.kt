package com.example.weightloss_pathway_project

import java.io.Serializable

open class DefinedGoal : Serializable{
    var goal : String = String()
    var dow : String = String()
    var planToComplete : String = String()
    var planToOvercome : String = String()
    var date : String = String()
}