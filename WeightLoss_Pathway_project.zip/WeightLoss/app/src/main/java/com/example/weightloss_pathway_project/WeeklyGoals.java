package com.example.weightloss_pathway_project;

public class WeeklyGoals {


}
