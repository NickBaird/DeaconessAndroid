package com.example.weightloss_pathway_project

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Message : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_message)
    }
}